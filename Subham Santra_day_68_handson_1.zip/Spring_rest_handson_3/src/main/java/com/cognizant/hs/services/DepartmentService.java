package com.cognizant.hs.services;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.hs.dao.DepartmentDao;
import com.cognizant.hs.dao.EmployeeDao;
import com.cognizant.hs.model.Department;

@Service
public class DepartmentService {

    @Autowired
    private DepartmentDao departmentDao;
    private static final Logger LOGGER = LoggerFactory.getLogger(EmployeeDao.class);

    public List<Department> getAllDepartments() {
	LOGGER.debug("Fetching all departments");
	return departmentDao.getAllDepartments();
    }

}