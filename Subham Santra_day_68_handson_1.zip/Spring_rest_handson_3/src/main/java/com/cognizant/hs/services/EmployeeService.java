package com.cognizant.hs.services;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.hs.dao.EmployeeDao;
import com.cognizant.hs.exceptions.EmployeeNotFoundException;
import com.cognizant.hs.model.Employee;

@Service
public class EmployeeService {

    private static final Logger LOGGER = LoggerFactory.getLogger(EmployeeDao.class);

    @Autowired
    private EmployeeDao employeeDao;

    public List<Employee> getAllEmployees() {
	LOGGER.debug("Fetching all employees");
	return employeeDao.getAllEmployee();
    }

    public Employee updateEmployee(Employee employee) throws EmployeeNotFoundException {
	LOGGER.debug("Updating employee");
	return employeeDao.updateEmployee(employee);
    }

    public void deleteEmployee(int id) throws EmployeeNotFoundException {
	LOGGER.debug("Deleting employee");
	employeeDao.deleteEmployee(id);
    }

}
