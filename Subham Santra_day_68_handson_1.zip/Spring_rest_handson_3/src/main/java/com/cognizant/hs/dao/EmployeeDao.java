package com.cognizant.hs.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.cognizant.hs.exceptions.EmployeeNotFoundException;
import com.cognizant.hs.model.Employee;

@Component
public class EmployeeDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(EmployeeDao.class);
    private static ArrayList<Employee> EMPLOYEE_LIST;

    @SuppressWarnings("unchecked")
    public EmployeeDao() {
	@SuppressWarnings("resource")
	ApplicationContext context = new ClassPathXmlApplicationContext("employee.xml");
	EMPLOYEE_LIST = (ArrayList<Employee>) context.getBean("employeeList");
    }

    public List<Employee> getAllEmployee() {
	LOGGER.debug("Fetching all Employee List");
	return EMPLOYEE_LIST;
    }

    public Employee updateEmployee(Employee employee) throws EmployeeNotFoundException {
	LOGGER.debug("updating employee with id {}", employee.getId());

	for (Employee varEmp : EMPLOYEE_LIST) {
	    if (varEmp.getId() == employee.getId()) {
		varEmp.setName(employee.getName());
		varEmp.setSalary(employee.getSalary());
		varEmp.setDateOfBirth(employee.getDateOfBirth());
		varEmp.setPermanent(employee.getPermanent());
		varEmp.setDepartment(employee.getDepartment());
		varEmp.setSkill(employee.getSkill());

		LOGGER.debug("updation complete!");
		return varEmp;
	    }
	}

	LOGGER.debug("updation failed cause EmployeeNotFound");
	throw new EmployeeNotFoundException();
    }

    public void deleteEmployee(int id) throws EmployeeNotFoundException {
	LOGGER.debug("deleting employee with id {}", id);

	boolean isDeleted = false;
	for (Iterator<Employee> iterator = EMPLOYEE_LIST.iterator(); iterator.hasNext();) {
	    Employee next = iterator.next();
	    if (next.getId() == id) {
		iterator.remove();
		isDeleted = true;
		LOGGER.debug("deletion completed!");
	    }
	}

	if (!isDeleted) {
	    LOGGER.debug("deletion failed! EmployeeNotFound");
	    throw new EmployeeNotFoundException();
	}
    }
}