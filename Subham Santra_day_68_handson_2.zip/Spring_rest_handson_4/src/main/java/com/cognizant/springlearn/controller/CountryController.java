package com.cognizant.springlearn.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.springlearn.model.Country;
import com.cognizant.springlearn.service.CountryService;
import com.cognizant.springlearn.service.exception.CountryNotFoundException;

@RestController
public class CountryController {

    private final Logger LOGGER = LoggerFactory.getLogger(CountryController.class);
    @Autowired
    private CountryService countryService;

    @GetMapping("/countries")
    public List<Country> getAllCountries() {
	LOGGER.info("START");
	LOGGER.debug("Calling getAllCountries() with method 'GET'");
	List<Country> countries = countryService.getCountries();
	LOGGER.info("END");
	return countries;
    }

    @GetMapping("/countries/{code}")
    public Country getCountry(@PathVariable String code) throws CountryNotFoundException {
	LOGGER.info("START");
	LOGGER.debug("Calling getCountry() with method 'GET' and code {}" + code);
	Country country = countryService.getCountry(code);
	LOGGER.info("END");
	return country;
    }

    @PostMapping("/countries")
    public void addCountry(@Valid @RequestBody Country country) {
	LOGGER.info("START");
	LOGGER.debug("Calling addCountry() with method 'POST' for country = {}", country);
	countryService.addCountry(country);
	LOGGER.info("END");
    }

    @PutMapping("/countries/{code}")
    public ResponseEntity<Country> updateCountry(@Valid @RequestBody Country country) {
	LOGGER.info("START");
	LOGGER.debug("Calling updateCountry() with method 'PUT' for country = {}", country);
	Country updateCountry = countryService.updateCountry(country);
	LOGGER.info("END");
	return ResponseEntity.ok(updateCountry);
    }

    @DeleteMapping("/countries/{code}")
    public ResponseEntity<?> deleteCountry(@PathVariable String code) throws CountryNotFoundException {
	LOGGER.info("START");
	LOGGER.debug("Calling deleteCountry() with method 'DELETE' for code = {}", code);
	boolean isDeleted = countryService.removeCountry(code);
	if (isDeleted) {
	    LOGGER.info("Deleted");
	    LOGGER.info("END");
	    return ResponseEntity.ok().build();
	} else {
	    LOGGER.info("Not deleted");
	    LOGGER.info("END");
	    return ResponseEntity.noContent().build();
	}
    }
}
